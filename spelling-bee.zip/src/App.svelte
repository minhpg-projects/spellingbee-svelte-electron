<script>
	export let name;
	import Card from './components/card.svelte'
</script>

<main>
	<Card />
</main>

<style>
main {margin: 0; height: 100%; overflow: hidden}
</style>